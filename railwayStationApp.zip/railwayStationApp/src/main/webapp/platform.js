/**
 * 
 */

 
 function confirmSubmit() {
        var platformNameInput = document.getElementById("platformName");
        var platformLocation = document.getElementById("platformLocation");
        var isOperational = document.getElementById("is_operational");
        var capacityInput = document.getElementById("capacity");
        var capacity = capacityInput.value.trim();
        var errorElement = document.getElementById("errorElement");
        var platformName = platformNameInput.value.trim();

        if (platformName.indexOf(" ") !== -1) {
            errorElement.textContent = "Platform Name should not contain spaces.";
            return false;
        }

        if (platformName === "") {
            errorElement.textContent = "Please Enter The Platform Name";
            return false;
        }
		
        if(platformLocation.value.trim() === ""){
        	errorElement.textContent = "Please Enter The Platform Location";
        	return false;
        }
       

        if (capacity === "") {
            errorElement.textContent = "Please enter a valid number for Capacity";
            return false;
        }
		
        if (isNaN(Number(capacity))) {
            errorElement.textContent = "Please enter a valid number for Capacity";
            return false;
        }
        capacity = Number(capacity);
        if (!Number.isInteger(capacity) || capacity <= 0) {
            errorElement.textContent = "Please enter a valid positive integer for Capacity";
            return false;
        }
        if (!isOperational.checked) {
            errorElement.textContent = "Please check the 'Is Operational?' checkbox.";
            return false;
        }
        errorElement.textContent = "";
        return true;
    }