package com.java.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="platform")
public class PlatformEntity{	
	@Id
	@Column(name = "PLATFORM_ID")
	int platformId;
	
	@Column(name="PLATFORM_NAME", unique = true)
	String platformName;
	
	@Column(name="PLATFORM_LOCATION")
	String platformLocation;
	
	@Column(name="CAPACITY")
	int capacity;
	
	@Column(name="IS_OPERATIONAL")
	boolean is_operational;
	

	public PlatformEntity() {
		
		System.out.println("Invoked Defalut constructor of PaltformEntity.");
		
	}
	public PlatformEntity(String platformName, String platformLocation, int capacity, boolean is_operational) {
		super();
		this.platformName = platformName;
		this.platformLocation = platformLocation;
		this.capacity = capacity;
		this.is_operational = is_operational;
	}



	public PlatformEntity(int platformId, String platformName, String platformLocation, int capacity,
			boolean is_operational) {
		super();
		this.platformId = platformId;
		this.platformName = platformName;
		this.platformLocation = platformLocation;
		this.capacity = capacity;
		this.is_operational = is_operational;
	}


	public void setPlatformId(int platformId) {
		
		this.platformId=platformId;
	}
	
	public int getPlatformId() {
		return platformId;
	}
	
	public void setPlatformName(String platformName) {
		this.platformName=platformName;
	}
	
	public String getPlatformName() {
		
		return platformName;
	}
	
	public void setPlatformLocation(String platformLocation) {
		this.platformLocation=platformLocation;
	}
	
	public String getPlatformLocation() {
		return platformLocation;
	}


	public int getCapacity() {
		return capacity;
	}



	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}



	public boolean isIs_operational() {
		return is_operational;
	}



	public void setIs_operational(boolean is_operational) {
		this.is_operational = is_operational;
	}



	@Override
	public String toString() {
		return "PlatformEntity [platformId=" + platformId + ", platformName=" + platformName + ", platformLocation="
				+ platformLocation + ", capacity=" + capacity + ", is_operational=" + is_operational + "]";
	}
	
	
}
