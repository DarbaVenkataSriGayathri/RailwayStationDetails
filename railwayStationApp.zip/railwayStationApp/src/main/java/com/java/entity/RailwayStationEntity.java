package com.java.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="station_table")
public class RailwayStationEntity {
	
	@Column(name="STATION_CODE")
	@Id
	String stationCode;
	
	@Column(name="STATION_NAME")
	String stationName;
	
	@Column(name="STATIONLOCATION")
	String stationLocation;
	
	
	@Column(name="NO_OF_PLATFORMS")
	int noOfPlatforms;
	
	public RailwayStationEntity() {
		System.out.println("RailwayStationEntity Contructor()");
	}

	

	public RailwayStationEntity(String stationCode, String stationName, String stationLocation, int noOfPlatforms) {
		super();
		this.stationCode = stationCode;
		this.stationName = stationName;
		this.stationLocation = stationLocation;
		this.noOfPlatforms = noOfPlatforms;
	}



	public String getStationCode() {
		return stationCode;
	}

	public void setStationCode(String stationCode) {
		this.stationCode = stationCode;
	}

	public String getStationName() {
		return stationName;
	}

	public void setStationName(String stationName) {
		this.stationName = stationName;
	}

	public String getStationLocation() {
		return stationLocation;
	}

	public void setStationLocation(String stationLocation) {
		this.stationLocation = stationLocation;
	}

	public int getNoOfPlatforms() {
		return noOfPlatforms;
	}

	public void setNoOfPlatforms(int noOfPlatforms) {
		this.noOfPlatforms = noOfPlatforms;
	}



	@Override
	public String toString() {
		return "RailwayStationEntity [stationCode=" + stationCode + ", stationName=" + stationName
				+ ", stationLocation=" + stationLocation + ", noOfPlatforms=" + noOfPlatforms + "]";
	}
	
	
}
