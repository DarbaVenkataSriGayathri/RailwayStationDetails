package com.java.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.java.entity.PlatformEntity;
import com.java.railwaystationdao.PlatformDAOImpl;


@Service
@Component
@Transactional 
public class PlatformService implements PlatformValidationService{
	
	
	private PlatformDAOImpl platformDAO;
	
	@Autowired
	public PlatformService(PlatformDAOImpl platformDAO) {
		
		this.platformDAO = platformDAO;
	}
	
	public PlatformService() {
		System.out.println("Service class defalut Constructor invoked");
	}
	
	
	@Override
	public boolean validatePlatformObject(String platformName, String platformLocation, int capacity, boolean is_operational) {
		
		System.out.println("validatePlatformObject invoked");
		

        boolean isValid = true;

        if (platformName == null || platformName.isEmpty()) {
            isValid = false;
            System.out.println("PlatformName is Invalid");
        } else {
            System.out.println("PlatformName is valid: " + platformName);
        }

        if (platformLocation == null || platformLocation.isEmpty()) {
            isValid = false;
            System.out.println("PlatformLocation is Invalid");
        } else {
            System.out.println("PlatformLocation is valid: " + platformLocation);
        }

        if (capacity <= 0) {
            isValid = false;
            System.out.println("Capacity is Invalid");
        } else {
            System.out.println("Capacity is valid: " + capacity);
        }

        if (!is_operational) {
            isValid = false;
            System.out.println("is_operational is Invalid");
        } else {
            System.out.println("is_operational is valid");
        }

		if(isValid) {
			PlatformEntity platformEntity = new PlatformEntity(platformName, platformLocation, capacity, is_operational );
			boolean result=platformDAO.savePlatform(platformEntity);
			return result;
		}
		return isValid;
	}

	@Override
	public boolean validatePlatformById(int platformId) {
		boolean isValid=true;
		if(platformId == 0) {
			
			System.out.println("Invalid PlatformId");
			isValid=false;	
		}
		else {
			System.out.println("Valid PlatformId");
		}
		return isValid;
	}
	
	@Override
	public PlatformEntity getPlatformById(int platformId) {
		
		System.out.println("getPlatformById platformId..");	
		return  platformDAO.getPlatformById(platformId);
		
	}

	@Override
	public boolean validatePlatformByName(String platformName) {
		boolean isValid=true;
		if(platformName==null || platformName.isEmpty()) {
			isValid=false;
			System.out.println("platformName is Invalid");
		}
		else {
			System.out.println("platformName is Valid");
		}
		return isValid;
	}
	
	@Override
	public PlatformEntity getPlatformDetailsByName(String platformName) {
		
		System.out.println("getPlatformDetailsByName...invoked");
		
		return platformDAO.getPlatformDetailsByName(platformName);
	}
	
}
