package com.java.service;

import com.java.entity.RailwayStationEntity;

public interface Railwayservice {
	

	boolean validateStationObject(String stationCode, String stationName, String stationLocation, int noOfPlatforms);
	
	boolean validateStationCode(String stationCode);
	
	RailwayStationEntity getRailwayStationEntityByStationCode(String stationCode);
	
	boolean validateStationObjectByName(String stationName);
	
	RailwayStationEntity getRailwayStationEntityByName(String stationName);
	
	RailwayStationEntity deleteRailwayStationEntityByCode(String stationCode);
	
	RailwayStationEntity deleteStationDetailsByName(String stationName);
	
	boolean updateRailwayStationEntity(String stationCode, String stationName, String stationLocation,
			int noOfPlatforms);
}