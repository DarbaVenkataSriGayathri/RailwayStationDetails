package com.java.service;

import com.java.entity.PlatformEntity;

public interface PlatformValidationService {
	
	boolean validatePlatformObject(String platformName, String platformLocation, int capacity, boolean is_operational);
	PlatformEntity getPlatformById(int platformId);
	boolean validatePlatformById(int platformId);
	boolean validatePlatformByName(String platfromName);
	PlatformEntity getPlatformDetailsByName(String platformName);
	
	
	
	
}