 package com.java.service;

import java.util.List;
import javax.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.java.entity.RailwayStationEntity;
import com.java.railwaystationdao.RailwayStationDAO;

@Service
@Component
@Transactional
public class RailwayStationService implements Railwayservice{
	
	
	private RailwayStationDAO railwayStationDAO;
	
	@Autowired
	public RailwayStationService(RailwayStationDAO railwayStationDAO) {
		this.railwayStationDAO = railwayStationDAO;
	}
	
	public RailwayStationService() {
		
		System.out.println("RailwayStation Service Method");
	}
	
	@Override
	@Transactional
	public boolean validateStationObject(String stationCode, String stationName, String stationLocation,  int noOfPlatforms) {
		System.out.println("validationStationObject...");
		
		boolean flag = true;  

		if (stationCode==null || stationCode.isEmpty() || stationCode.length()==0) {
			flag = false; 
			 
			System.out.println("StationCode is InValid");
//			throw new StationCodeValidationException("StationCode is invalid");
		}
		else {
			System.out.println("StationCode is Valid");
		}

		if (stationName == null || stationName.isEmpty()) {
			flag = false;  
			System.out.println("Station Name is InValid");
//			throw new StationNameValidationException("Station Name is invalid");
		}
		else {
			System.out.println("StationName is valid");
		}

		if (stationLocation == null || stationLocation.isEmpty()) {
			flag = false;  
			
			System.out.println("stationLocation is InValid");
//			throw new StationLocationValidationException("Station Location is invalid");
		}
		else {
			System.out.println("StationLocation is valid");
		}

		if (noOfPlatforms <= 0) {
			flag = false;  
			
			System.out.println("Number of Platforms is InValid");
//			throw new NoOfPlatformsValidationException("Number of Platforms is invalid");
		}
		else {
			System.out.println("Number of Platforms is valid");
		}

		if(flag) {
			
			RailwayStationEntity railwayStationEntity=new RailwayStationEntity(stationCode, stationName, stationLocation, noOfPlatforms);
			boolean result=railwayStationDAO.saveRailwayStationEntity(railwayStationEntity);
			return result;
		}
		return flag;
//		
	}
	
//	public boolean saveRailwayStationEntity(RailwayStationEntity railwayStationEntity) {
//		
//		
//		System.out.println("saveRailwayStationEntity(RailwayStationEntity railwayStationEntity)....executed");
//		return railwayStationDAO.saveRailwayStationEntity(railwayStationEntity);
//	}
	
	@Override
	public boolean validateStationCode(String stationCode) {
		
		boolean flag=false;

		if(stationCode !=null && !stationCode.isEmpty() && stationCode.length()>0 && stationCode.length()<=10) {
			System.out.println("Invoked ValidateStationCode for statusCode " +stationCode);
			flag=true;
			System.out.println("StationCode is Valid for statusCode "+stationCode);
		}
		return flag;
		
		
	}

	@Override
	public RailwayStationEntity getRailwayStationEntityByStationCode(String stationCode) {
		
		System.out.println(" getRailwayStationEntityByStationCode() is executed...");
		
		return railwayStationDAO.getRailwayStationEntityByStationCode(stationCode);
	}

	@Override
	public boolean validateStationObjectByName(String stationName) {
		
		boolean flag=false;
		
		if(stationName !=null && !stationName.isEmpty()) {
			
			System.out.println("validateStationObjectByName(String stationName) is executed");
			flag=true;
			System.out.println("stationName is Valid");
		}
		return flag;
		
	}

	@Override
	public RailwayStationEntity getRailwayStationEntityByName(String stationName) {
		
		System.out.println("getRailwayStationEntityByStationName()");
		
		return railwayStationDAO.getRailwayStationEntityByStationName(stationName);
	}

	

	@Override
	public RailwayStationEntity deleteRailwayStationEntityByCode(String stationCode) {
		
		System.out.println(" deleteRailwayStationEntityByCode for Code "+ stationCode);
		
		return railwayStationDAO.deleteRailwayStationEntityByCode(stationCode);
		
	}

	@Override
	public RailwayStationEntity deleteStationDetailsByName(String stationName) {
		
		System.out.println("deleteStationDetailsByName(String stationName)... executed");
		
		return railwayStationDAO.deleteRailwayDetailsByName(stationName);
	}
	
	public List<RailwayStationEntity> getAllRailwayEntity(){
		
		return railwayStationDAO.getAllRailwayEntity();
	}

	
	@Override
	public boolean updateRailwayStationEntity(String stationCode, String stationName, String stationLocation,
			int noOfPlatforms) {
		
		System.out.println("Invoked updateRailwayStationEntity...");
		RailwayStationEntity entity = new RailwayStationEntity(stationCode, stationName, stationLocation, noOfPlatforms);
		return railwayStationDAO.updateStationEntity(entity);
	}

	public String isDatabaseEmpty() {
	
		return "Database Empty";
	}

	
	
}
