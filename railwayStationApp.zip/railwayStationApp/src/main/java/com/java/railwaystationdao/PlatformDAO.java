package com.java.railwaystationdao;

import com.java.entity.PlatformEntity;

public interface PlatformDAO {
	

	boolean savePlatform(PlatformEntity platformEntity);
	PlatformEntity getPlatformById(int platformId);
	PlatformEntity getPlatformDetailsByName(String platformName);

}
