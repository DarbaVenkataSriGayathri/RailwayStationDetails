package com.java.railwaystationdao;

import java.util.List;

import com.java.entity.RailwayStationEntity;

public interface RailwayStationDAO {
	
	

	boolean saveRailwayStationEntity(RailwayStationEntity railwayStationEntity);
	
	RailwayStationEntity getRailwayStationEntityByStationCode(String stationCode);

	RailwayStationEntity getRailwayStationEntityByStationName(String stationName);

	RailwayStationEntity deleteRailwayStationEntityByCode(String stationCode);

	RailwayStationEntity deleteRailwayDetailsByName(String stationName);

	
	List<RailwayStationEntity> getAllRailwayEntity();
	boolean updateStationEntity(RailwayStationEntity entity);

}
