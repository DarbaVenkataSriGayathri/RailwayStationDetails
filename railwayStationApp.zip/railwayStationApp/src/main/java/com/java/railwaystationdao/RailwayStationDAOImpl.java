package com.java.railwaystationdao;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.java.entity.RailwayStationEntity;

@Component
public class RailwayStationDAOImpl implements RailwayStationDAO{	 
	
	private SessionFactory sessionFactory;
	private Query query;
	private Session session;
	
	@Autowired
	public RailwayStationDAOImpl(SessionFactory sessionFactory) {
	
		this.sessionFactory = sessionFactory;
		System.out.println("RailwayStation DAO Implementation ...");
	}

	@Override
	@Transactional
	public boolean saveRailwayStationEntity(RailwayStationEntity railwayStationEntity) {
		System.out.println("Invoked the saveRailwayStationEntity()");
		session=null;
		Transaction transaction=null;
		boolean isDataSaved=false;
		try {
			
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Serializable save = session.save(railwayStationEntity);
			System.out.println("save=" +save);
			session.getTransaction().commit();
			System.out.println("Session has been saved");
			isDataSaved=true;
		}
		catch(HibernateException e) {
			
			transaction.rollback();
			System.out.println("transaction failed..");
		}
		finally {
			
			if(session!=null) {
				
				session.close();
				System.out.println("Session closed");
			}
			
		}
		return isDataSaved;	
	}

	@Override
	public RailwayStationEntity getRailwayStationEntityByStationCode(String stationCode) {
		
		System.out.println("Invoked the  getRailwayStationEntityByStationCode()");
		session=null;
		RailwayStationEntity entity=null;
		try {
			
			session = sessionFactory.openSession();
			entity = session.get(RailwayStationEntity.class, stationCode);
			
			if(entity !=null) {
				
				System.out.println("stationCode RailwayStationEntity is found..");
				
				return entity;
				
			}
		}
		finally {
			
			if(session!=null) {
				
				session.close();
				System.out.println("Session closed");
			}
			
		}
		
		return entity;
	}

	@Override
	public RailwayStationEntity getRailwayStationEntityByStationName(String stationName) {
		
		System.out.println("Invoked  getRailwayStationEntityByStationName()");
		session=null;
		RailwayStationEntity entity=null;
		String hql="from RailwayStationEntity where stationName='"+stationName+"'";
		
		try {
			
			 session=sessionFactory.openSession();
			 query = session.createQuery(hql);
			 entity=(RailwayStationEntity)query.uniqueResult();
			 System.out.println(entity);
			 return entity;
			 
		} finally {
			if(session !=null) {
				
				session.close();
				System.out.println("Session closed");
			}
		}
		
	}

	@Override
	public RailwayStationEntity deleteRailwayStationEntityByCode(String stationCode) {
		
		session=null;
		RailwayStationEntity entity=null;
		Transaction transaction=null;
		String hql="from RailwayStationEntity where stationCode='"+stationCode+"'";
		
		try {	
			session  = sessionFactory.openSession();
			transaction=session.beginTransaction();
			session.clear();
			query = session.createQuery(hql);
			entity=(RailwayStationEntity) query.uniqueResult();
			entity = session.get(RailwayStationEntity.class,stationCode);
			
			if(entity !=null) {
				System.out.println("entity to delete: "+ entity.getStationCode());
				session.delete(entity);
				System.out.println("Deleted row..");
			}
			else {
				System.out.println("Entity with code " + stationCode + " not found. Deletion skipped.");
				}
			transaction.commit();
			
		}
		catch(Exception e) {
			System.out.println("Exception for delete status code "+ e.getMessage());
			if(transaction!=null) {
				
				transaction.rollback();
			}
			e.printStackTrace();
		}
		finally {
			
			if(session!=null) {
				
				session.close();
			}
			
		}
		return entity;
		
	}


	@Override
	public RailwayStationEntity deleteRailwayDetailsByName(String stationName) {
		
		Session session=null;
		Transaction transaction=null;
		RailwayStationEntity entity=null;
		String hql="from RailwayStationEntity where stationName='"+stationName+"'";
		try {
			
			session = sessionFactory.openSession();	
			transaction = session.beginTransaction();
			query = session.createQuery(hql);
			entity=(RailwayStationEntity) query.uniqueResult();	
			if(entity!=null) {
				
				session.delete(entity);
				System.out.println("entity Deleted");
			}
			else {
				
				System.out.println("entity Not Deleted");
			}
			transaction.commit();
		}
		
		
		catch(Exception e) {
			
			if(transaction !=null) {
				
				transaction.rollback();
			}
			e.printStackTrace();
		}
		finally {
			
			if(session!=null) {
				
				session.close();
			}
		}
		return entity;
	}

	@Override
	public List<RailwayStationEntity> getAllRailwayEntity() {
		
		System.out.println("List<RailwayStationEntity> getAllRailwayEntity()...");
		Session session=null;
		String hql="from RailwayStationEntity";
		
		
		try {
			
			session = sessionFactory.openSession();
			query = session.createQuery(hql);
			List<RailwayStationEntity> resultList = query.getResultList();
			
			return resultList;
			
			
		}
		finally {
			
			if(session!=null) {
				
				session.close();
				System.out.println("session closed()..");
			}
		}
	}

	@Override
	public boolean updateStationEntity(RailwayStationEntity entity) {
		Session session=null;
		Transaction transaction=null;
		try {
			
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.update(entity);
			session.getTransaction().commit();
			return true;
		}
		catch(Exception e) {
			
			if(transaction!=null) {
				
				transaction.rollback();
			}
		}
		finally {
			
			if(session!=null) {
				
				session.close();
			}
		}
		return false;
		
	}
}
		
		
