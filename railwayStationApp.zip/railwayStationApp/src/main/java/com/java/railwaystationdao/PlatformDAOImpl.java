package com.java.railwaystationdao;

import java.io.Serializable;

import javax.transaction.Transactional;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.java.entity.PlatformEntity;


@Component
public class PlatformDAOImpl implements PlatformDAO{
	
	
	private SessionFactory sessionFactory;
	private Query query;
	private Session session;

	
	@Autowired
	public PlatformDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	public PlatformDAOImpl() {
		
		System.out.println("PlatformDAOImpl invoked");
	}
		

	@Override
	@Transactional
	public boolean savePlatform(PlatformEntity platformEntity) {
		
		System.out.println("savePlatformDetails invoked");
		
		boolean isDataSave=false;
		Transaction transaction=null;
		Session session=null;
		try{
			
			session = sessionFactory.openSession();	
			transaction = session.beginTransaction();	
			Serializable save = session.save(platformEntity);	
			System.out.println("save Entity "+save);	
			transaction.commit();
			System.out.println("Session save Entity");
			isDataSave=true;
			
		}
		 catch (Exception e) {
	            if (transaction != null) {
	                transaction.rollback();
	                System.out.println("Transaction not saved, rolled back");
	            }
	            e.printStackTrace(); 
		}
		finally {
			
			if(session!=null) {
				
				session.close();
				System.out.println("Session closed..");
			}
			
		}	
		return isDataSave;
	}


	@Override
	public PlatformEntity getPlatformById(int platformId) {
		session=null;
		System.out.println("getPlatformId invoked..");
		PlatformEntity entity=null;
		try{
				
			session = sessionFactory.openSession();
			entity = session.get(PlatformEntity.class, platformId);
			if(entity!=null) {
				
				System.out.println("PLATFORM ID IS FOUND");
				return entity;
				
			}
			else {
				System.out.println("PLATFORM ID IS NOT FOUND");
			}
		}
		finally {
			
			if(session!=null) {
				session.close();
				System.out.println("Session closed ..");
			}
			
		}
		return entity;	
		
	}

	@Override
	public PlatformEntity getPlatformDetailsByName(String platformName) {
		Session session=null;
		PlatformEntity entity=null;
		String hql="from PlatformEntity where platformName='"+platformName+"'";
		try{
			
			session = sessionFactory.openSession();
			query = session.createQuery(hql);
			entity = session.get(PlatformEntity.class, platformName);
			query.uniqueResult();
			if(entity!=null) {
				
				System.out.println("PLATFORM NAME IS FOUND");
				return entity;
			}
			else {
				System.out.println("PLATFORM NAME IS  NOT FOUND");
			}		
		}
		finally {
			
			if(session != null){
				
				session.close();
			}
		}
		
		return null;
	}


}
