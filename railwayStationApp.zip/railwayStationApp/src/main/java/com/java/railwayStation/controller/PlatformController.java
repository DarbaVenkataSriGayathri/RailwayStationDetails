package com.java.railwayStation.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import com.java.entity.PlatformEntity;
import com.java.service.PlatformService;


@Controller
public class PlatformController {
		
	private PlatformService platformService;
	
	@Autowired
	public PlatformController(PlatformService platformService) {
	    this.platformService = platformService;
	}
	
	public PlatformController() {
		System.out.println("PlatformController invoked");
	}
	@RequestMapping(value = "/savePlatformDetails", method = RequestMethod.POST)
	public String savePlatformDetails(@RequestParam String platformName,
	        @RequestParam String platformLocation,
	        @RequestParam (required = false) Integer capacity,
	        @RequestParam (name = "is_operational", required = false)boolean is_operational, Model model) {

	    System.out.println("savePlatformDetails Method invoked in Controller class.");
	    
	    System.out.println("Platform Name " + platformName);
	    System.out.println("Platform Location " + platformLocation);
	    System.out.println("Capacity " + capacity);
	    System.out.println("Is_operational " + is_operational);
	    
	    if (platformName == null || platformName.isEmpty() ||
	            platformLocation == null || platformLocation.isEmpty() ||
	            capacity == null || capacity <= 0) {

	            // Handle validation errors
	            model.addAttribute("responseMessage", " Please provide Details");
	            model.addAttribute("isValid", false);
	            return "/platform.jsp";  // Adjust the view name accordingly
	        }
	    boolean isValid = platformService.validatePlatformObject(platformName, platformLocation, capacity, is_operational);

	    if (isValid) {
	  
	        model.addAttribute("responseMessage", "DATA IS VALID & SAVED IN DATABASE ");
	        model.addAttribute("isValid", true);
	      

	    } else {
	        model.addAttribute("responseMessage", "DATA IS INVALID & TRY AGAIN...");
	        model.addAttribute("isValid", false);
	    }

	    return "/platform.jsp";
	}
	
	@RequestMapping(value="/searchPlatformDetailsById", method=RequestMethod.POST)
	public String searchPlatformDetailsById(@RequestParam int platformId, Model model) {
		boolean result=platformService.validatePlatformById(platformId);
		if(result) {
			System.out.println("platformId"+platformId);
			PlatformEntity entity = platformService.getPlatformById(platformId);
			if(entity!=null) {
				
				model.addAttribute("PLATFORMID", entity.getPlatformId());
				model.addAttribute("PLATFORMNAME",entity.getPlatformName());
				model.addAttribute("PLATFORMLOCATION", entity.getPlatformLocation());
				model.addAttribute("CAPACITY", entity.getCapacity());
				model.addAttribute("IS_OPERATIONAL",entity.isIs_operational());
				
			}
			else {
				model.addAttribute("responseMessage","PlatformId Doesn't Exist");
			}
		}
		else {
			model.addAttribute("responseMessage","PlatformId is Invalid");
		}
		return "/platform.jsp";
	}
	
	
	
	@RequestMapping(value="/searchPlatformByName", method=RequestMethod.POST)
	public String  searchPlatformByName(@RequestParam String platformName, Model model) {
		
		boolean result=platformService.validatePlatformByName(platformName);
		if(result) {
			
			PlatformEntity entity = platformService.getPlatformDetailsByName(platformName);
			if(entity!=null) {
				
				model.addAttribute("platformId",entity.getPlatformId());
				model.addAttribute("platformName",entity.getPlatformName());
				model.addAttribute("platformLocation",entity.getPlatformLocation());
				model.addAttribute("capacity",entity.getCapacity());
				model.addAttribute("is_operational", entity.isIs_operational());
			}
			else {
				model.addAttribute("responseMessage","PlatformName Doesn't Exist");
			}
		}
		else {
			model.addAttribute("responseMessage","PlatformName Is Invalid");
		}
		return "/platform.jsp";
		
		
	}
	
	
}
