package com.java.railwayStation.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.java.entity.RailwayStationEntity;
import com.java.service.RailwayStationService;

@Controller
public class RailwayController {
	
	private RailwayStationService railwayStationService;
	
	@Autowired	
	public RailwayController(RailwayStationService railwayStationService) {
		this.railwayStationService = railwayStationService;
	}
	
	public RailwayController() {
		System.out.println("Object created the Spring MVC ioc Container....");
	}
	
	@RequestMapping(value = "/getDataFromHtml", method=RequestMethod.POST)
	public String acceptFirstRequest(@RequestParam String stationCode, 
			@RequestParam String stationName, 
			@RequestParam String stationLocation, 
			@RequestParam int noOfPlatforms,
			Model model){
		
		System.out.println("Invoked Accept First Request");
		System.out.println("RailwayStationCode"+stationCode);
		System.out.println("RailwayStationName"+stationName);
		System.out.println("RailwayStationLocation"+stationLocation);
		System.out.println("Number of Platforms.."+noOfPlatforms);
		boolean isValid = railwayStationService.validateStationObject(stationCode, stationName, stationLocation, noOfPlatforms);
		if (isValid) {
			model.addAttribute("responseMessage", "DATA IS VALID & SAVED IN DATABASE");
			model.addAttribute("isValid", true);
		} else {
			model.addAttribute("responseMessage", "DATA IS INVALID & TRY AGAIN...");
			model.addAttribute("isValid", false);
		}

		 return "/index.jsp";
		
	}
	
	@RequestMapping(value="/searchdetails", method=RequestMethod.POST)
	public String searchRailwayObject(@RequestParam String stationCode, Model model) {
		
		System.out.println("RailwayStationCode=" +stationCode);
		boolean result=railwayStationService.validateStationCode(stationCode);
		if(result) {
			RailwayStationEntity entity=railwayStationService.deleteRailwayStationEntityByCode(stationCode);
			
			if(entity!=null) {
				
				model.addAttribute("STATIONCODE", entity.getStationCode());
				model.addAttribute("STATIONNAME", entity.getStationName());
				model.addAttribute("STATIONLOCATION", entity.getStationLocation());
				model.addAttribute("NOOFPLATFORMS", entity.getNoOfPlatforms());
					
			}
			else {
				
				model.addAttribute("message", "RailwayStationEntity Doesn't Exist try with valid StationCode");
				
			}
					
		}
		else {
			
			model.addAttribute("message", "Invalid stationCode... stationCode Length() cannot be 0");
		}
		return "/index.jsp";
		
	}	
	
	@RequestMapping(value="/searchdetailsByName")
	public String searchRailwayObjectByName(@RequestParam String stationName, Model model) {
		
		System.out.println("StationName" +stationName);
		boolean result = railwayStationService.validateStationObjectByName(stationName);
		if(result) {
			
			RailwayStationEntity entity = railwayStationService.getRailwayStationEntityByName(stationName);
			if(entity!=null) {
				
				model.addAttribute("StationCode", entity.getStationCode());
				model.addAttribute("StationName", entity.getStationName());
				model.addAttribute("StationLocation", entity.getStationLocation());
				model.addAttribute("NoOfPlatforms", entity.getNoOfPlatforms());
				
			}
			else {
				model.addAttribute("responseMessage", "RailwayStationEntity Doesn't Exist try with valid StationName");
			}
		}
		else {
			
			model.addAttribute("responseMessage", "Invalid StationName... stationName");
		}
		return "/index.jsp";
	}
	
	@RequestMapping(value="/deleteDetailsByCode", method=RequestMethod.POST)
	public String deleteRailwayObjectByCode(@RequestParam String stationCode, Model model) {
		
		boolean result = railwayStationService.validateStationCode(stationCode);
		if(result) {
			
			RailwayStationEntity entity = railwayStationService.deleteRailwayStationEntityByCode(stationCode) ;
			if(entity!=null) {
				
				model.addAttribute("STATION_CODE", entity.getStationCode());
				model.addAttribute("STATION_NAME", entity.getStationName());
				model.addAttribute("STATION_LOCATION", entity.getStationLocation());
				model.addAttribute("NO_OF_PLATFORMS",entity.getNoOfPlatforms());		
			}
			else {
				model.addAttribute("responseMessage", "RailwayStationEntity Doesn't Exist try with valid StationCode");
			}
		}
		else {
			
			model.addAttribute("responseMessage", "Invalid StationCode... stationCode");
		}
		return "/index.jsp";	
	}
	
	@RequestMapping(value="/deletedetailsByName", method=RequestMethod.POST)
	public String deleteRailwayDetailsByName(@RequestParam String stationName, Model model) {
		
		boolean result=railwayStationService.validateStationObjectByName(stationName);
		if(result) {
			
			RailwayStationEntity entity=railwayStationService.deleteStationDetailsByName(stationName);
			
			if(entity!=null) {
				
				model.addAttribute("Station_Code", entity.getStationCode());
				model.addAttribute("Station_Name", entity.getStationName());
				model.addAttribute("Station_Location", entity.getStationLocation());
				model.addAttribute("No_Of_Platforms", entity.getNoOfPlatforms());
				
			}
			else {
				
				model.addAttribute("responseMessage", "RailwayStaionEntity Doesn't exist try again with valid StationName");
				
			}
		}
		else {
			
			model.addAttribute("responseMessage", "Invalid StationName");
		}
		
		return "/index.jsp";
	}
	
	@RequestMapping(value="/getAllDetails")
	public String getAllRailwaydetails(Model model) {
		
		System.out.println("Invoked getAllDetails()");
		
		List<RailwayStationEntity> allRailwayEntity = railwayStationService.getAllRailwayEntity();
		
		model.addAttribute("Railways", allRailwayEntity);
		return "/index.jsp";
	}
	
	
	
	@RequestMapping(value="/editRailwayDetails/{code}")
	public String editRailwayStationByCode(@PathVariable String code, Model model) {
		
		System.out.println(" editRailwayStationByCode code)....");
		
		RailwayStationEntity entity = railwayStationService.getRailwayStationEntityByStationCode(code);
		if(entity!=null) {
			
			model.addAttribute("station_code", entity.getStationCode());
			model.addAttribute("station_name", entity.getStationName());
			model.addAttribute("station_location", entity.getStationLocation());
			model.addAttribute("noofplatforms", entity.getNoOfPlatforms());
		}
		
		return "/WEB-INF/edit.jsp";
	}
	
	
	@RequestMapping(value="/updatedetailsByCode", method=RequestMethod.POST)
	public String updateRailwayStation(@RequestParam String stationCode, @RequestParam String stationName, @RequestParam String stationLocation, @RequestParam int noOfPlatforms, Model model) {
		
		System.out.println("update RailwayStation Method Invoked..");
		
		boolean result = railwayStationService.updateRailwayStationEntity(stationCode, stationName, stationLocation, noOfPlatforms);
		if(result) {
			
			model.addAttribute("responseMessage", "RailwayStationEntity has been updated");
		}
		else {
			
			model.addAttribute("responseMessage", "RailwayStationEntity not been updated");
		}
		return "/index.jsp";
	}
	
	
	@RequestMapping(value="/deletedetails/{code}")
	public String deletedetails(@PathVariable String code, RedirectAttributes redirectAttributes)
	{
		System.out.println("deleteDetails...");
		boolean result = railwayStationService.validateStationCode(code);
		if(result) {
			
			RailwayStationEntity entity = railwayStationService.deleteRailwayStationEntityByCode(code) ;
			if(entity!=null) {
				
				 System.out.println("Deleted entity with code: " + code);
				 redirectAttributes.addFlashAttribute("responseMessage", "Row with code" +code+ "Successfully deleted");
				 
			}
			else {
				
				System.out.println("RailwayStation entity with code doesn't exist");
				redirectAttributes.addFlashAttribute("responseMessage","Row with code"+code+ "doesn't exist");
				
			}
		}
		else {
			
			System.out.println("Invalid StationCode: " + code);
			redirectAttributes.addFlashAttribute("responseMessage", "Invalid StationCode... stationCode");
			
		}
		redirectAttributes.addFlashAttribute("isEmpty",railwayStationService.isDatabaseEmpty());
		return "redirect:/getAllDetails";
	}
	

	

		
}

